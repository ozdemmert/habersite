<?php
require_once __DIR__ . '/../include/functions.php';
$socialObj = new Social();
$socialLinks = $socialObj->getAll();
$socialMap = [];
foreach ($socialLinks as $s) {
    $socialMap[strtolower($s['platform'])] = $s['social_url'];
}
?>
    <footer class="bg-white border-t border-gray-200">
        <div class="max-w-5xl mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <h3 class="font-bold text-lg mb-4 text-[#022d5a]">Hakkımızda</h3>
                    <p class="text-sm text-gray-600">Güncel haberler, derinlemesine analizler ve farklı bakış açılarıyla Türkiye'nin en güvenilir haber kaynağı. Her gün en güncel ve doğru haberleri sizlere sunuyoruz.</p>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-4 text-[#022d5a]">Bağlantılar</h3>
                    <ul class="space-y-2">
                        <li><a href="hakkimizda" class="text-sm text-gray-600 hover:text-[#f39200]">Hakkımızda</a></li>
                        <li><a href="kunye" class="text-sm text-gray-600 hover:text-[#f39200]">Künye</a></li>
                        <li><a href="iletisim" class="text-sm text-gray-600 hover:text-[#f39200]">İletişim</a></li>
                        <li><a href="gizlilik" class="text-sm text-gray-600 hover:text-[#f39200]">Gizlilik Politikası</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-4 text-[#022d5a]">Takip Et</h3>
                    <div class="flex space-x-4">
                        <?php if (!empty($socialMap['facebook'])): ?>
                        <a href="<?php echo htmlspecialchars($socialMap['facebook']); ?>" target="_blank" class="text-[#022d5a] hover:text-[#f39200]">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($socialMap['twitter'])): ?>
                        <a href="<?php echo htmlspecialchars($socialMap['twitter']); ?>" target="_blank" class="text-[#022d5a] hover:text-[#f39200]">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723 10.03 10.03 0 01-3.127 1.195 4.93 4.93 0 00-8.391 4.49 13.986 13.986 0 01-10.147-5.147 4.93 4.93 0 001.525 6.57 4.885 4.885 0 01-2.23-.616c-.054 2.281 1.581 4.415 3.949 4.89a4.93 4.93 0 01-2.224.084 4.93 4.93 0 004.6 3.419 9.87 9.87 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.069a13.917 13.917 0 007.548 2.212c9.057 0 14.009-7.499 14.009-13.999 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($socialMap['instagram'])): ?>
                        <a href="<?php echo htmlspecialchars($socialMap['instagram']); ?>" target="_blank" class="text-[#022d5a] hover:text-[#f39200]">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2c-5.52 0-10 4.48-10 10s4.48 10 10 10 10-4.48 10-10-4.48-10-10-10zm5.82 15.84c-.24.516-.692.942-1.242 1.17-.686.283-1.522.439-2.495.457a9.98 9.98 0 01-1.697-.147 4.5 4.5 0 01-1.657-.635 3.2 3.2 0 01-1.054-1.085 3.03 3.03 0 01-.366-1.494v-7.022A3.1 3.1 0 019.6 7.842a3.11 3.11 0 011.289-1.007 4.33 4.33 0 011.788-.412c1.121 0 1.951.263 2.488.793.537.53.806 1.234.806 2.105v8.374a3.11 3.11 0 01-.133 1.144zm-2.746-1.089c.325-.047.605-.132.842-.253.237-.122.41-.29.52-.505a1.87 1.87 0 00.164-.826V9.045c0-.715-.186-1.235-.559-1.56-.372-.324-.969-.487-1.78-.487-.597 0-1.044.123-1.34.368a1.73 1.73 0 00-.444.511 1.94 1.94 0 00-.203.642 5.63 5.63 0 00-.05.739v8.578c0 .235.05.442.15.62.1.18.278.329.534.446.256.116.627.18 1.112.191.147 0 .283-.003.406-.01a5.12 5.12 0 00.648-.078z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($socialMap['youtube'])): ?>
                        <a href="<?php echo htmlspecialchars($socialMap['youtube']); ?>" target="_blank" class="text-[#022d5a] hover:text-[#f39200]">
                            <i class="fab fa-youtube text-2xl"></i>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($socialMap['linkedin'])): ?>
                        <a href="<?php echo htmlspecialchars($socialMap['linkedin']); ?>" target="_blank" class="text-[#022d5a] hover:text-[#f39200]">
                            <i class="fab fa-linkedin text-2xl"></i>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($socialMap['tiktok'])): ?>
                        <a href="<?php echo htmlspecialchars($socialMap['tiktok']); ?>" target="_blank" class="text-[#022d5a] hover:text-[#f39200]">
                            <i class="fab fa-tiktok text-2xl"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="mt-4">
                        <a href="index.php">
                            <img src="assets/images/minilogo.png" alt="Logo" class="h-12 w-auto mx-auto">
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-8 pt-4 border-t border-gray-200">
                <p class="text-sm text-gray-600">&copy; <?php echo date('Y'); ?> Gazete BanDor. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>
</body>
</html> 