<?php
require_once '../include/functions.php';
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: ../login.php');
    exit();
}

$news = new News($conn);
$section = new Section($conn);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $success = true;
    
    // Update YouTube video
    if (isset($_POST['youtube_video'])) {
        $data = ['youtube_url' => $_POST['youtube_video']];
        if (!$section->updateOrCreate('youtube_video', $data)) {
            $success = false;
        }
    }
    
    // Update main sections
    foreach (['main1', 'main2'] as $sectionName) {
        if (isset($_POST[$sectionName])) {
            $data = ['news_id' => $_POST[$sectionName]];
            if (!$section->updateOrCreate($sectionName, $data)) {
                $success = false;
            }
        }
    }

    // Update story sections
    foreach (['story1', 'story2', 'story3'] as $sectionName) {
        if (isset($_POST[$sectionName])) {
            $data = ['news_id' => $_POST[$sectionName]];
            if (!$section->updateOrCreate($sectionName, $data)) {
                $success = false;
            }
        }
    }

    if ($success) {
        header('Location: section.php?success=1');
        exit();
    } else {
        $error = "Bir hata oluştu. Lütfen tekrar deneyin.";
    }
}

// Get all news
$all_news = $news->getAll();
$current_selections = $section->getAllGrouped();

$page_title = 'Section Manager';
?>

<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body class="bg-gray-100">
    <?php include 'components/sidebar.php'; ?>

    <div class="ml-64 flex-1 h-screen overflow-y-auto">
        <?php include 'components/header.php'; ?>

        <main class="p-8">
            <?php if (isset($_GET['success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                    <span class="block sm:inline">Bölüm seçimleri başarıyla güncellendi!</span>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
                    <span class="block sm:inline"><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="section.php">
                <div class="mb-6">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded">
                        <i class="fas fa-save mr-2"></i>Değişiklikleri Kaydet
                    </button>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6 space-y-8">
                    <!-- YouTube Video Section -->
                    <div class="space-y-6">
                        <h2 class="text-xl font-bold mb-4">YouTube Video</h2>
                        <div class="flex items-center gap-4 p-4 bg-gray-50 rounded">
                            <label class="w-32 font-medium">Video URL</label>
                            <input type="text" name="youtube_video" 
                                value="<?php echo isset($current_selections['youtube_video']) ? htmlspecialchars($current_selections['youtube_video']) : ''; ?>"
                                placeholder="https://www.youtube.com/watch?v=..." 
                                class="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        <p class="text-sm text-gray-500">YouTube video URL'sini girin (örn: https://www.youtube.com/watch?v=VIDEO_ID)</p>
                    </div>

                    <!-- Main Sections -->
                    <div class="space-y-6">
                        <h2 class="text-xl font-bold mb-4">Ana Bölümler</h2>
                        <?php foreach (['main1', 'main2'] as $section): ?>
                            <div class="flex items-center gap-4 p-4 bg-gray-50 rounded">
                                <label class="w-32 font-medium"><?php echo ucfirst($section); ?></label>
                                <select name="<?php echo $section; ?>" class="flex-1 rounded-md border-gray-300 shadow-sm">
                                    <option value="">Haber Seçin</option>
                                    <?php foreach ($all_news as $news_item): ?>
                                        <option value="<?php echo $news_item['id']; ?>"
                                            <?php if (isset($current_selections[$section]) && $current_selections[$section] == $news_item['id']) echo 'selected'; ?>>
                                            <?php echo htmlspecialchars($news_item['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Story Sections -->
                    <div class="space-y-6">
                        <h2 class="text-xl font-bold mb-4">Hikaye Bölümleri</h2>
                        <?php foreach (['story1', 'story2', 'story3'] as $section): ?>
                            <div class="flex items-center gap-4 p-4 bg-gray-50 rounded">
                                <label class="w-32 font-medium"><?php echo ucfirst($section); ?></label>
                                <select name="<?php echo $section; ?>" class="flex-1 rounded-md border-gray-300 shadow-sm">
                                    <option value="">Haber Seçin</option>
                                    <?php foreach ($all_news as $news_item): ?>
                                        <option value="<?php echo $news_item['id']; ?>"
                                            <?php if (isset($current_selections[$section]) && $current_selections[$section] == $news_item['id']) echo 'selected'; ?>>
                                            <?php echo htmlspecialchars($news_item['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </form>
        </main>
    </div>
</body>
</html>