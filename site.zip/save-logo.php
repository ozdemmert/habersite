<?php
// Define the destination path
$target_dir = "assets/img/";
$target_file = $target_dir . "mini-logo.png";

// Create the directory if it doesn't exist
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}

// Base64 encoded Bandor logo (blue and orange circular logo with letter B)
 